package com.spot.on.demo;

import com.spot.on.demo.models.Chessboard;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import java.io.File;

public class DemoApplication {

	public static void main(String[] args) throws JAXBException {
		String inputLocation = getPathToFile(args);
		print21(inputLocation);
	}

	private static String getPathToFile(String[] args) {
		if (args.length == 0) {
			throw new IllegalArgumentException("Please provide path!");
		}
		return args[0];
	}

	private static void print21(String inputLocation) throws JAXBException {
		JAXBContext jc = JAXBContext.newInstance(Chessboard.class);
		Unmarshaller unmarshaller = jc.createUnmarshaller();
		Chessboard chessboard = (Chessboard) unmarshaller.unmarshal(new File(inputLocation));
		for(Chessboard.Piece piece : chessboard.getPiece()) {
			System.out.println("Figure: " + piece.getFigure() + "\nPosition: " + piece.getPosition() + "\n");
		}
	}

}
