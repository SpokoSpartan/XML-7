package com.spot.on.demo;

import com.spot.on.demo.models.Catalog;
import org.apache.commons.lang.RandomStringUtils;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import java.io.File;
import java.util.Random;

public class DemoApplication {

	public static void main(String[] args) throws JAXBException {
		String pathToFile = getPathToFile(args);
		print(pathToFile);
	}

	private static String getPathToFile(String[] args) {
		if (args.length == 0) {
			throw new IllegalArgumentException("Please provide path!");
		}
		return args[0];
	}

	private static void print(String pathToFile) throws JAXBException {
		JAXBContext jc = JAXBContext.newInstance(Catalog.class);
		Unmarshaller unmarshaller = jc.createUnmarshaller();
		Catalog catalog = (Catalog) unmarshaller.unmarshal(new File(pathToFile));
		System.out.println("Catalog:");
		for(Catalog.Book book : catalog.getBook()) {
			System.out.println("Book:\nId: " + book.getId() + "\nTitle: " + book.getTitle() +
					"\nGenre: " + book.getGenre() +"\nAuthor: " + book.getAuthor() + "\nPrice: " + book.getPrice() +
					"\nDescription: " + book.getDescription() + "\nPublishDate: " + book.getPublishDate() + "\n");
		}
	}

}
