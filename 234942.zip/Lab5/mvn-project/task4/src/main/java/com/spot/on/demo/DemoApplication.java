package com.spot.on.demo;

import com.spot.on.demo.models.Catalog;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import java.io.File;
import java.text.DecimalFormat;
import java.util.Date;

public class DemoApplication {


	public static void main(String[] args) throws JAXBException {
		String pathToFile = getPathToFile(args);
		print(pathToFile);
	}

	private static String getPathToFile(String[] args) {
		if (args.length == 0) {
			throw new IllegalArgumentException("Please provide path!");
		}
		return args[0];
	}

	private static void print(String pathToFile) throws JAXBException {
		JAXBContext jc = JAXBContext.newInstance(Catalog.class);
		Unmarshaller unmarshaller = jc.createUnmarshaller();
		Catalog catalog = (Catalog) unmarshaller.unmarshal(new File(pathToFile));
		printMostExpensive(catalog);
		printAveragePrice(catalog);
		printOldest(catalog);
	}

	public static void printMostExpensive(Catalog catalog) {
		float price = 0;
		Catalog.Book mostExpensive = null;
		for (Catalog.Book book : catalog.getBook()) {
			if (book.getPrice().floatValue() > price) {
				mostExpensive = book;
				price = book.getPrice().floatValue();
			}
		}
		System.out.println("Most expensive book:\nId: " + mostExpensive.getId() + "\nTitle: " + mostExpensive.getTitle() +
				"\nGenre: " + mostExpensive.getGenre() + "\nAuthor: " + mostExpensive.getAuthor() + "\nPrice: " + mostExpensive.getPrice() +
				"\nDescription: " + mostExpensive.getDescription() + "\nPublishDate: " + mostExpensive.getPublishDate() + "\n");
	}

	public static void printAveragePrice(Catalog catalog) {
		double allPrices = 0;
		for (Catalog.Book book : catalog.getBook()) {
			allPrices += book.getPrice().floatValue();
		}
		DecimalFormat df = new DecimalFormat("0.00");
		System.out.println("Average price: " + df.format(allPrices / catalog.getBook().size()) + "\n");
	}

	public static void printOldest(Catalog catalog) {
		Catalog.Book oldest = null;
		Date oldestDate = null;
		for (Catalog.Book book : catalog.getBook()) {
			if (oldestDate == null) {
				oldestDate = book.getPublishDate();
			}
			if (book.getPublishDate().before(oldestDate)) {
				oldest = book;
				oldestDate = book.getPublishDate();
			}
		}
		System.out.println("Oldest book:\nId: " + oldest.getId() + "\nTitle: " + oldest.getTitle() +
				"\nGenre: " + oldest.getGenre() + "\nAuthor: " + oldest.getAuthor() + "\nPrice: " + oldest.getPrice() +
				"\nDescription: " + oldest.getDescription() + "\nPublishDate: " + oldest.getPublishDate() + "\n");
	}

}
