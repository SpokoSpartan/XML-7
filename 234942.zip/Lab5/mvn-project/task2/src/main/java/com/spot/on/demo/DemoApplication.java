package com.spot.on.demo;

import com.spot.on.demo.models.Menu;
import org.apache.commons.lang.RandomStringUtils;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import java.io.File;
import java.util.Random;

public class DemoApplication {

	private static final Random RANDOM = new Random();

	public static void main(String[] args) throws JAXBException {
		generate();
	}

	private static void generate() throws JAXBException {
		Menu menu = new Menu();
		for (int i = 0; i < 100; i++) {
			menu.addFood(generateRandomFood());
		}
		JAXBContext ctx = JAXBContext.newInstance(Menu.class);
		Marshaller marshaller = ctx.createMarshaller();
		marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		marshaller.marshal(menu, System.out);
	}

	private static Menu.Food generateRandomFood() {
		Menu.Food food = new Menu.Food();
		food.setCalories(RANDOM.nextInt());
		food.setCategory(RandomStringUtils.randomAlphabetic(10));
		food.setDescription(RandomStringUtils.randomAlphabetic(30));
		food.setName(RandomStringUtils.randomAlphabetic(20));
		food.setPrice(RANDOM.nextFloat());
		return food;
	}

}
