#!/bin/bash
java -jar app.jar
