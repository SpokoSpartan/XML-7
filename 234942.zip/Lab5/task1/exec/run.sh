#!/bin/bash
java -jar app.jar chessboard.xml
